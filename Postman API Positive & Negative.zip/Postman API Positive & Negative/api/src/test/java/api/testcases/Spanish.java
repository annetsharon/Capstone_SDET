package api.testcases;

import api.general.ExcelUtilities;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Iterator;

public class Spanish {
    @BeforeTest
    public static void getInputdata() throws IOException {
        RestAssured.useRelaxedHTTPSValidation();

    }
    @Test
    public void tfn_call() throws JsonProcessingException {
        RestAssured.baseURI = "https://restcountries.com";

        RequestSpecification httpRequest = RestAssured.given();

        httpRequest.header("Content-Type", "application/json");
        httpRequest.header("Cache-Control", "no-cache");

        // V parm set
//        httpRequest.queryParam("salesChannel", "RESI-COM");
//        httpRequest.queryParam("affiliateId","218700");
        Response response = httpRequest.request(Method.GET,"/v3.1/lang/spanish");

        System.out.println("Response: " + response.getBody().asString());
        int statusCode = response.getStatusCode();
//        excelUtilities.setCellData("PROD","Status",2,statusCode+"");
        System.out.println("Status code: " + statusCode);
        Assert.assertEquals("200",statusCode);
    }

    @AfterMethod
    public void fetchMostRecentTestResult(ITestResult result) {

        int status = result.getStatus();

        switch (status) {
            case ITestResult.SUCCESS:
                // Excel_Utility.setCellData("Results", "Status", 5, "PASS");
                break;
            case ITestResult.FAILURE:
                //  Excel_Utility.setCellData("Results", "Status", 5, "FAIL");
                break;
            case ITestResult.SKIP:
                // Excel_Utility.setCellData("Results", "Status", 5, "SKIP");
                break;
            default:
                throw new RuntimeException("Invalid status");
        }
    }
}
