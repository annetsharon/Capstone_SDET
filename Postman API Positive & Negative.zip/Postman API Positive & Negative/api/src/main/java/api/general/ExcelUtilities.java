package api.general;

import org.apache.commons.logging.Log;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class ExcelUtilities {
    public static String path = System.getProperty("user.dir") + "\\DataSheet\\TFN.xlsx";
    public static FileInputStream fis = null;
    public static FileOutputStream fileOut = null;
    private static XSSFWorkbook workbook = null;
    private static XSSFSheet sheet = null;
    public static XSSFRow row = null;
    private static XSSFCell cell = null;

    //System.out.(" "+path);
    static {
        System.out.println("Hello World\n" + path);
//        System.exit(0);
    }

    /**
     * @param sheetName  - Sheet name of the excel
     * @param columnName
     * @param rowNum
     * @param data
     */
    public static boolean setCellData(String sheetName, String columnName, int rowNum, String data) {
        try {
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            if(rowNum<=0)
                return false;

            int index = workbook.getSheetIndex(sheetName);
            int colNum=-1;
            if(index==-1)
                return false;
            sheet = workbook.getSheetAt(index);
            row=sheet.getRow(0);
            for(int i=0;i<row.getLastCellNum();i++){
                //System.out.println(row.getCell(i).getStringCellValue().trim());
                if(row.getCell(i).getStringCellValue().trim().equals(columnName))
                    colNum=i;
            }
            if(colNum==-1)
                return false;
            sheet.autoSizeColumn(colNum);
            row = sheet.getRow(rowNum-1);
            if (row == null)
                row = sheet.createRow(rowNum-1);

            cell = row.getCell(colNum);
            if (cell == null)
                cell = row.createCell(colNum);
            CellStyle cs = workbook.createCellStyle();
            cs.setWrapText(true);
            cell.setCellValue(data);
            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

}
